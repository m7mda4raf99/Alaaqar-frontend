import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photos-uploader',
  templateUrl: './photos-uploader.component.html',
  styleUrls: ['./photos-uploader.component.scss']
})
export class PhotosUploaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
